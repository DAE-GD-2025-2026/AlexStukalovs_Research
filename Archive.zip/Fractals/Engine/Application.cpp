// Project
#include "Application.hpp"
#include "Utils.hpp"
// Third-party
#include "SDL3/SDL.h"
// Standard
#include <cmath>

static SDL_Window* g_pSDLWindow{};
static SDL_Renderer* g_pSDLRenderer{};

#pragma region Vector2u
LSystems::Engine::Vector2u LSystems::Engine::Vector2u::operator+=(Vector2u const rhs) noexcept
{
    this->x = rhs.x;
    this->y = rhs.y;
    return *this;
}

LSystems::Engine::Vector2u LSystems::Engine::operator+(Vector2u lhs, Vector2u const rhs) noexcept
{
    return lhs += rhs;
}
#pragma endregion Vector2u

#pragma region Application
LSystems::Engine::Application::Application(std::string_view const name, Vector2u const windowDims)
    : m_windowDims{ windowDims }
{
    // Initializing SDL
    Utils::Check(SDL_InitSubSystem(SDL_INIT_VIDEO),
        "SDL_Init(SDL_INIT_VIDEO) Error"
    );

    // Creating window and renderer
    Utils::Check(
        SDL_CreateWindowAndRenderer(
            name.data(),
            static_cast<int>(windowDims.x), static_cast<int>(windowDims.y),
            SDL_WINDOW_OPENGL,
            &g_pSDLWindow, &g_pSDLRenderer
            ),
        "Failed to initialize SDL window and renderer"
    );
}

void LSystems::Engine::Application::Run(VisualizationData const& data) noexcept {
    while (true) {

        // Processing events

        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_EVENT_QUIT: return;
                default:;
            }
        }

        // Rendering

        // Clearing the background with black
        SDL_SetRenderDrawColor(g_pSDLRenderer, 0, 0, 0, SDL_ALPHA_OPAQUE);
        SDL_RenderClear(g_pSDLRenderer);

        // Drawing the L-System
        DrawLSystem(data);

        // Showing the new frame
        SDL_RenderPresent(g_pSDLRenderer);
    }
}

void DrawLine(LSystems::Engine::Vector2u const p1, LSystems::Engine::Vector2u const p2) noexcept
{
    SDL_RenderLine(g_pSDLRenderer,
        static_cast<float>(p1.x),
        static_cast<float>(p1.y),
        static_cast<float>(p2.x),
        static_cast<float>(p2.y)
    );
}

void LSystems::Engine::Application::DrawLSystem(VisualizationData const& data) noexcept {
    // Setting white color
    SDL_SetRenderDrawColor(g_pSDLRenderer, 255, 255, 255, SDL_ALPHA_OPAQUE);

    float radians{};
    Vector2u prevPointPx{ data.startingPointPx };
    for (char const c : data.stage)
    {
        switch (c)
        {
        case 'F':
        {
            // Drawing a line in the current direction
            Vector2u const newPointPx{
                prevPointPx + Vector2u{
                    static_cast<uint32_t>(std::cosf(radians) * static_cast<float>(data.lineLengthPx)),
                    static_cast<uint32_t>(std::sinf(radians) * static_cast<float>(data.lineLengthPx)),
                }
            };
            DrawLine(
                prevPointPx, newPointPx
            );
            prevPointPx = newPointPx;
            break;
        }
        case '+':
            // Rotating 90 degrees
            radians += 0.5f * std::numbers::pi;
            break;
        default: ;
        }
    }

}
#pragma endregion Application
