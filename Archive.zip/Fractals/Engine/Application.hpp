﻿#ifndef APPLICATION_HPP
#define APPLICATION_HPP
// Standard
#include <cstdint>
#include <string_view>

namespace LSystems::Engine {

#pragma region Vector2u
    struct Vector2u final
    {
        uint32_t x{}, y{};
        [[nodiscard]] Vector2u operator+=(Vector2u rhs) noexcept;
    };

    [[nodiscard]] Vector2u operator+(Vector2u lhs, Vector2u rhs) noexcept;

#pragma endregion Vector2u

    struct VisualizationData final
    {
        std::string_view stage{};
        Vector2u const startingPointPx{};
        uint32_t const lineLengthPx{};
        uint32_t const lineWidthPx{5u};
    };

#pragma region Application
    // The simplest SDL wrapper serving a single-only purpose of visualizing L-systems
    class Application final {
    public:
        explicit Application(std::string_view name, Vector2u windowDims);

        // Draws the L-system and quits if Escape is pressed
        void Run(VisualizationData const&) noexcept;

    private:
        Vector2u m_windowDims;

        static void DrawLSystem(VisualizationData const&) noexcept;
    };
#pragma endregion Application

}

#endif// APPLICATION_HPP
