﻿// Project
#include "Fractals.hpp"
#include "D0L.hpp"
// Engine
#include "Engine/Application.hpp"
// Standard
#include <print>

void LSystems::RunD0LVisualizer() {
    std::println("Fractal visualizer");

    // LSystems::D0L const d0l{
    //     LSystems::GetD0LFromUser()
    // };

    // LSystems::Stages const stages{
    //     LSystems::GenerateStages(d0l)
    // };

    std::string const axiom{ };
    Engine::Vector2u constexpr windowDims{ 1280, 720 };

    Engine::Application engine{ "D0L visualizer", windowDims };
    engine.Run(Engine::VisualizationData{
        .stage = "F",
        .startingPointPx = { windowDims.x / 4, 3 * windowDims.y / 4 },
        .lineLengthPx = 50u
    });
}
