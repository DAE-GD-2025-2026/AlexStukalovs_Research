// Project
#include "LSystem.hpp"
// Engine
#include "Engine/Application.hpp"
#include "Engine/Utils.hpp"

int main()
{
    using namespace LSystems;

    Stages const stages{ GenerateStages(LSystem{
        .axiom = "F",
        .rules = {{ 'F', "F[+F]F[-F]F" }},
        .stageCount = 5,
    }) };
    VisualizationData constexpr visualiztion{
        .absRadians = Engine::Utils::ToRadians(25.7f),
        .startRadians = Engine::Utils::ToRadians(90.f)
    };

    Engine::Application const engine{ "Branching structures", {720, 720} };
    engine.Run(
        stages, visualiztion
    );
}
