// Project
#include "Application.hpp"
#include "Utils.hpp"
// Third-party
#include "SDL3/SDL.h"
// Standard
#include <algorithm>
#include <cassert>
#include <cmath>
#include <format>
#include <ranges>
#include <stack>

static SDL_Window* g_pSDLWindow{};
static SDL_Renderer* g_pSDLRenderer{};

#pragma region Application
LSystems::Engine::Application::Application(std::string_view const name, Vector2f const windowDims)
    : m_windowDims{ windowDims }
{
    // Initializing SDL
    Utils::Check(SDL_InitSubSystem(SDL_INIT_VIDEO),
        "SDL_Init(SDL_INIT_VIDEO) Error"
    );

    // Creating window and renderer
    Utils::Check(
        SDL_CreateWindowAndRenderer(
            name.data(),
            static_cast<int>(windowDims.x), static_cast<int>(windowDims.y),
            SDL_WINDOW_OPENGL,
            &g_pSDLWindow, &g_pSDLRenderer
            ),
        "Failed to initialize SDL window and renderer"
    );
}

auto LSystems::Engine::Application::Run(Stages const stages, VisualizationData const& data) const noexcept -> void{
    uint32_t stageIdx{};
    float lineLengthPx{ data.startingLineLengthPx };

    while (true) {

        // Processing events

        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_EVENT_QUIT: return;
                case SDL_EVENT_KEY_UP:
                    switch (event.key.scancode)
                    {
                        case SDL_SCANCODE_LEFT:
                        {
                            if (stageIdx == 0) break;

                            if ((--stageIdx %= stages.size()) == 0)
                                lineLengthPx = data.startingLineLengthPx;
                            else
                                lineLengthPx *= data.absLengthScaleFactor;
                            break;
                        }
                        case SDL_SCANCODE_RIGHT:
                        {
                            if (stageIdx == stages.size() - 1) break;

                            if ((++stageIdx %= stages.size()) == 0)
                                lineLengthPx = data.startingLineLengthPx;
                            else
                                lineLengthPx /= data.absLengthScaleFactor;
                            break;
                        }
                        default:;
                    }

                    break;
                default:;
            }
        }

        // Rendering

        // Clearing the background with black
        SDL_SetRenderDrawColor(g_pSDLRenderer, 0, 0, 0, SDL_ALPHA_OPAQUE);
        SDL_RenderClear(g_pSDLRenderer);

        // Drawing the L-System
        DrawStage(stages.at(stageIdx), data);

        // Showing the new frame
        SDL_RenderPresent(g_pSDLRenderer);
    }
}

auto LSystems::Engine::Application::DrawStage(std::string_view const stage, VisualizationData const& data) const -> void
{
    SDL_SetRenderDrawColor(g_pSDLRenderer, 255, 255, 255, SDL_ALPHA_OPAQUE);// Setting white color
    for (Line const& line : GenerateLines(stage, data)) DrawLine(line);
}

struct State final
{
    LSystems::Vector2f point{};
    float radians{}, lineLengthPx{};
};

auto LSystems::Engine::Application::GenerateLines(std::string_view const stage, VisualizationData const& data) const -> std::vector<Line>
{
    // Allocating point history
    std::vector<Line> lines;
    lines.reserve(std::ranges::count(stage, 'F'));
    lines.emplace_back();// Starting point = {0, 0}

    // Allocating state stack
    std::stack<State> savedStates;
    State currentState{{}, data.startRadians, data.startingLineLengthPx};

    // Generating the points
    for (char const character : stage)
    {
        switch (character)
        {
        case 'F':
        {
            // Drawing a line in the current direction
            Vector2f const newPointPx {
                currentState.point + Vector2f {
                    std::cosf(currentState.radians) * currentState.lineLengthPx,
                    std::sinf(currentState.radians) * currentState.lineLengthPx,
                }
            };
            lines.emplace_back(currentState.point, newPointPx);
            currentState.point = newPointPx;
            break;
        }
        case '+':// "Turning left"
            currentState.radians += data.absRadians;
            break;
        case '-':// "Turning right"
            currentState.radians -= data.absRadians;
            break;
        case '[':// Pushing the state to the stack
            savedStates.push(currentState);
            break;
        case ']':// Popping the state from the stack
            if (savedStates.empty()) break;
            currentState = savedStates.top();
            savedStates.pop();
            break;
        default:
            throw std::logic_error{std::format("Invalid character {}", character)};
        }
    }

    CenterLines(lines);
    return lines;
}

// NOTE: The origin is bottom left
auto LSystems::Engine::Application::DrawLine(Line const& line) const noexcept -> void
{
    SDL_RenderLine(g_pSDLRenderer,
        line.p1.x,
        m_windowDims.y - line.p1.y,
        line.p2.x,
        m_windowDims.y - line.p2.y
    );
}

auto LSystems::Engine::Application::DrawCircle(Vector2f const center, float const radius) const noexcept -> void
{
    // Thanks, SDL, for not having a default circle-drawing function

    float constexpr pi{ std::numbers::pi_v<float> };

    int32_t const pointCount{
        std::max(
            static_cast<int32_t>(2.f * pi * radius),// Circumference in px(point per px)
            8// Making small circles not degenerate to 1 or 2 segments
        )
    };

    for (int32_t const pointIdx : std::ranges::views::iota(0, pointCount)) {
        // Calculating 2 subsequent points on the circumference
        float const p1{ 2.f * pi * static_cast<float>(pointIdx) / static_cast<float>(pointCount) },
            p2{ 2.f * pi * static_cast<float>(pointIdx + 1) / static_cast<float>(pointCount) };

        // Drawing the circumference segment
        DrawLine({
            {center.x + radius * cosf(p1), center.y + radius * sinf(p1)},
            {center.x + radius * cosf(p2), center.y + radius * sinf(p2)}
        });
    }
}

auto GetAABB(std::vector<LSystems::Line> const& lines) -> SDL_FRect
{
    if (lines.empty()) throw std::invalid_argument("Input array must not be empty");

    float minX{ lines.front().p1.x }, maxX{ minX },
        minY{ lines.front().p1.y }, maxY{ minY };

    for (auto const& [p1, p2] : lines)
    {
        for (auto const& [x, y] : { p1, p2 })
        {
            minX = std::min(minX, x);  maxX = std::max(maxX, x);
            minY = std::min(minY, y);  maxY = std::max(maxY, y);
        }
    }

    return SDL_FRect{ minX, minY, maxX - minX, maxY - minY };
}

auto LSystems::Engine::Application::CenterLines(std::vector<Line>& lines) const noexcept -> void
{
    auto const [x, y, w, h]{ GetAABB(lines) };
    Vector2f const aabbCenter{ x + 0.5f * w, y + 0.5f * h },
        offsetVector{ 0.5f * m_windowDims - aabbCenter };

    std::ranges::transform(lines, lines.begin(), [&offsetVector](Line const& line) -> Line
    {
        return Line(line.p1 + offsetVector, line.p2 + offsetVector);
    });
}

#pragma endregion Application
